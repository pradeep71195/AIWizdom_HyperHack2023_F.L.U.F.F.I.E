from customInput import customData
import json
import numpy 
import random
import sklearn
import os
try:
    from sklearn.externals import joblib
except:
    import joblib

#X = "['Sunday', 'Cloudy', '2', '20', '0.3', '2', '8.531383302864107', 'No Preference', '1']"

class Main(object):
    def __init__(self):
        preprocessor_path = os.path.join("artifacts", "preprocessor.pkl")
        print("preprocessor load")
            
        model_path = os.path.join("artifacts", "model.pkl")
        print("model load")
            
        with open(preprocessor_path, 'rb') as picked_file:
            self.preprocessor = joblib.load(picked_file)
            #preprocessor = load_object(preprocessor_path)
        print("preprocessor loading completed")
            
        with open(model_path, 'rb') as model_file:
            self.model = joblib.load(model_file)
            #model = load_object(model_path)
        print("model loading completed")
            
    def predict(self, inputValue):
        inputValue = eval(inputValue)
        data=customData(
            dayOfTheWeek=inputValue[0],
            weather=inputValue[1], 
            holiday=int(inputValue[2]), 
            reservations=int(inputValue[3]), 
            occupancyRate=float(inputValue[4]), 
            event=int(inputValue[5]), 
            averageCheck=float(inputValue[6]), 
            guestPreferences=inputValue[7], 
            localEvents=int(inputValue[8]),
            traffic=random.choice([1, 3])##Choose random between 1,2,3
            )
        final_new_data = data.get_data_as_dataframe()
        pred = self.prediction(final_new_data)
        results = round(pred[0], 2)
        print("Result - "+str(results))
        return (json.dumps({"result":str(results)}))
        
    def prediction(self, features):
        try:            
            data_scaled = self.preprocessor.transform(features)
            print("data transformed")
            pred = self.model.predict(data_scaled)
            print("returning predicted value"+pred)
            return pred
        except Exception as e:
            print("Exception in prediction")

#fun = Main()
#fun.predict(X)