import pandas as pd

class customData:
    def __init__(
                self,
                dayOfTheWeek:str,
                weather:str,
                holiday:int,
                reservations:int,
                occupancyRate:float,
                event:int,
                averageCheck:float,
                guestPreferences:str,
                localEvents:int,
                traffic: int):
        self.dayOfTheWeek = dayOfTheWeek
        self.weather = weather
        self.holiday = holiday
        self.reservations = reservations
        self.occupancyRate = occupancyRate
        self.event = event
        self.averageCheck = averageCheck
        self.guestPreferences = guestPreferences
        self.localEvents = localEvents
        self.traffic = traffic

    def get_data_as_dataframe(self):
        try:
            custom_input = {
                'dayOfTheWeek':[self.dayOfTheWeek],
                'weather':[self.weather],
                'holiday':[self.holiday],
                'reservations':[self.reservations],
                'occupancyRate':[self.occupancyRate],
                'event':[self.event],
                'averageCheck':[self.averageCheck],
                'guestPreferences':[self.guestPreferences],
                'localEvents':[self.localEvents],
                'traffic':[self.traffic]
            }
            df = pd.DataFrame(custom_input)
            print("Dataframe generated")
            return df
        except Exception as e:
            print("Exception in getting Data frame")        
